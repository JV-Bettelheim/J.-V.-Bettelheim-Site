import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useState } from "react";

function Home() {
  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-4xl font-serif mb-4">J.V. Bettelheim</h1>
      <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
        Author. Screenwriter. Reader of too many books. Welcome to my corner of the web where I talk stories, dissect philosophy, and post work-in-progress writing.
      </p>
      <div className="space-y-4">
        <section>
          <h2 className="text-2xl font-bold mb-2">Featured Book Review</h2>
          <p className="text-gray-600 dark:text-gray-400 italic">"The Unbearable Lightness of Meaning – a review of *Kafka on the Shore*"</p>
        </section>
        <section>
          <h2 className="text-2xl font-bold mb-2">Writing Excerpt</h2>
          <p className="text-gray-600 dark:text-gray-400 italic">From *Glass City* – Chapter One</p>
        </section>
        <section>
          <h2 className="text-2xl font-bold mb-2">Philosophical Essay</h2>
          <p className="text-gray-600 dark:text-gray-400 italic">"Are We Real, or Are We Writing Ourselves?"</p>
        </section>
      </div>
    </div>
  );
}

function NavBar() {
  const [open, setOpen] = useState(false);
  return (
    <nav className="bg-white dark:bg-gray-800 border-b p-4 shadow-md sticky top-0 z-50">
      <div className="max-w-5xl mx-auto flex justify-between items-center">
        <Link to="/" className="text-xl font-serif font-bold dark:text-white">J.V. Bettelheim</Link>
        <div className="md:hidden">
          <button onClick={() => setOpen(!open)} className="text-gray-600 dark:text-gray-300">☰</button>
        </div>
        <ul className={\`md:flex gap-6 \${open ? "block" : "hidden"} md:block text-gray-700 dark:text-gray-300\`}>          
          <li><Link to="/" className="hover:text-black dark:hover:text-white">Home</Link></li>
        </ul>
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <Router>
      <NavBar />
      <Routes>
        <Route path="/" element={<Home />} />
      </Routes>
    </Router>
  );
}
